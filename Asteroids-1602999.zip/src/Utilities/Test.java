package Utilities;

import java.util.Random;

/**
 * Created by kairo on 13/03/2018.
 */
public class Test {
    public static void main(String[] args) {

    }
}
