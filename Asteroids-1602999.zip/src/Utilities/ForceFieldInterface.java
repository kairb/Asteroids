package Utilities;
import Utilities.Vector2D;

import static game1.Constants.DT;

public interface ForceFieldInterface {
    public void update(GameObject obj, double DT);

}