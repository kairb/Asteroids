package Utilities;

/**
 * Created by kairo on 01/02/2018.
 */
public interface Controller {
    public Action action();

}